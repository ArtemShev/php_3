<?php
class SmsNotifier extends Notifier
{
    //код
    public function sendNotification($message)
    {
        //todo smthg
        parent::sendNotification($message);
    }
}