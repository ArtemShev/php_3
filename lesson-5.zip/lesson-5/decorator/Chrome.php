<?php
class ChromeNotifier extends Notifier
{

    public function sendNotification($message)
    {
        //todo smthg
        parent::sendNotification($message);
    }
}