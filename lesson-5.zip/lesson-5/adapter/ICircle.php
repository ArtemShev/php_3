<?php
interface ICircle
{
function circleArea(int $circumference);
}