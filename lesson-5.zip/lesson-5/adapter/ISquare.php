<?php
interface ISquare
{
function squareArea(int $sideSquare);

}
