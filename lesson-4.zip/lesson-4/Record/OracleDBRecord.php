<?php
class OracleDBRecord implements DBRecord{
    public function recordDB(): string{
        return "Oracle has been recorded";
    }
}