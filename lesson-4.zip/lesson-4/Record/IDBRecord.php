<?php
interface DBRecord
{
    public function recordDB() : string;
}