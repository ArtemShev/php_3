<?php
class OracleDBQueryBuiler implements DBQueryBuilder
{
    public function buildQueryDB() : string
    {
        return " Oracle query has been builded";
    }
}