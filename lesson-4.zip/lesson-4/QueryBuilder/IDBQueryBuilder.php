<?php
interface DBQueryBuilder
{
    public function buildQueryDB() : string;
}