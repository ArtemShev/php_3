<?php
interface DBconnection
{
    public function connectDB() : string;
}